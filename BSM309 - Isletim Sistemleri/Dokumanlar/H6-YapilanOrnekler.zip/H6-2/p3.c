#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>


int main() {
  int pid;

  pid = fork();

  if(pid == 0) {
    printf("Merhaba ben yavru prosesim: %d\n", pid);
    while(1) ;
  } else if(pid > 0) {
    printf("Merhaba ben ebeveynim: %d\n", pid);
    while(1) ;
  } else if (pid < 0) {
    perror("FORK HATASI!");
  }
  return 0;
}
