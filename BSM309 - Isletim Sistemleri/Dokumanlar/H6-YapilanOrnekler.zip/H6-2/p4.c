#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/wait.h>



int main() {
  int pid;
  int sts;

  pid = fork();

  if(pid == 0) {
    printf("Merhaba ben yavru prosesim: %d\n", pid);


    execlp("/usr/bin/xeyes", "/usr/bin/xeyes", NULL);

    printf("Merhaba Burası execlp den sonraki kısım");
    
  } else if(pid > 0) {
    printf("Merhaba ben ebeveynim: %d\n", pid);
    wait(&sts);
    printf("Yavru icrasını tamamladı, durum kodu: %d\n", sts);
  } else if (pid < 0) {
    perror("FORK HATASI!");
  }
  return 0;
}
