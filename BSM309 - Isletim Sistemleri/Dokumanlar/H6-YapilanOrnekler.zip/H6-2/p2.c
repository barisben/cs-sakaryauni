#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>


int main() {
  int pid;

  pid = fork();
  pid = fork();
  pid = fork();
  

  printf("Merhaba %d\n", pid);
  
  //  printf("Merhaba %d\n", pid);

  return 0;
}
