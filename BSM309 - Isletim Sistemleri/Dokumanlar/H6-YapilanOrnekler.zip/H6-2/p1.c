#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>


int main() {
  int pid, ppid;

  pid = getpid();
  ppid = getppid();

  printf("PID: %d\n", pid);
  printf("PPID: %d\n", ppid);

  while(1) ; // Sonsuz döngü

  return 0;
}
